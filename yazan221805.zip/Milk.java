public class Milk extends Ingredient {
    private int volume;
    private Color color;

    public Milk(String name, int calories, int volume, Color color) {
        super(name, calories);
        this.volume = volume;
        this.color = color;
    }

    public int getVolume() {
        return volume;
    }

    public Color getColor() {
        return color;
    }

    @Override
    public String getInfo() {
        
        return "Milk: " + name + ", Calories: " + calories + ", Volume: " + volume + ", Color: " + color.getInfo();
    }
}
