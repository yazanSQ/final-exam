import java.util.ArrayList;

public class Cocktail {
    private int calories;
    private final ArrayList<Ingredient> ingredients;
    private Color color;

    public Cocktail() {
        ingredients = new ArrayList<>();
    }

    public void addIngredient(Ingredient ingredient) {
        ingredients.add(ingredient);
        calories += ingredient.getCalories();
    }

    public int getCalories() {
        return calories;
    }

    public ArrayList<Ingredient> getIngredients() {
        return ingredients;
    }

    public Color getColor() {
        return color;
    }

    public String getInfo() {
        StringBuilder info = new StringBuilder("Cocktail: ");
        for (Ingredient ingredient : ingredients) {
            info.append(ingredient.getInfo()).append(", ");
        }
        info.append("Total Calories: ").append(calories);
        return info.toString();
    }
}