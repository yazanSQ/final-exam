public class Fruit extends Ingredient {
    private int volume;
    private Color color;

    public Fruit(String name, int calories, int volume, Color color) {
        super(name, calories);
        this.volume = volume;
        this.color = color;
    }

    public int getVolume() {
        return volume;
    }

    public Color getColor() {
        return color;
    }

    @Override
    public String getInfo() {
        return "Fruit: " + name + ", Calories: " + calories + ", Volume: " + volume + ", Color: " + color.getInfo();
    }
}