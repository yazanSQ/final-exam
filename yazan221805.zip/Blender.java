import java.util.ArrayList;
import java.util.logging.Logger;

public class Blender {
    private ArrayList<Ingredient> ingredients;
    private int capacity;
    private int calories;
    private Color color;
    private int volume;
    private Logger logger;


    Blender(int i, Logger logger) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void addIngredient(Ingredient ingredient) throws BlenderOverflowException {
        if (volume + ingredient.getVolume() > capacity) {
            throw new BlenderOverflowException("Blender overflow: Cannot add more ingredients.");
        }
        ingredients.add(ingredient);
        volume += ingredient.getVolume();
        calories += ingredient.getCalories();
    }

    public Cocktail blend() throws BlenderEmptyException {
        if (ingredients.isEmpty()) {
            throw new BlenderEmptyException("Blender is empty: No ingredients to blend.");
        }
        Cocktail cocktail = new Cocktail();
        for (Ingredient ingredient : ingredients) {
            cocktail.addIngredient(ingredient);
        }
        ingredients.clear();
        volume = 0;
        return cocktail;
    }

    public String getInfo() {
        return "Blender: Capacity: " + capacity + ", Current Volume: " + volume + ", Total Calories: " + calories;
    }
}
