public class BlenderOverflowException extends Exception {
    public BlenderOverflowException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
