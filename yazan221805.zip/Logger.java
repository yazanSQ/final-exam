public interface Logger {
    void log(String message);
}
