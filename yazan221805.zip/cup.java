public class cup {
    private int capacity;
    private int calories;

    public cup(int capacity, int calories) {
        this.capacity = capacity;
        this.calories = calories;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getCalories() {
        return calories;
    }

    public String getInfo() {
        return "Cup: Capacity: " + capacity + ", Calories: " + calories;
    }
}