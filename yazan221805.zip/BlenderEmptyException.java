public class BlenderEmptyException extends Exception {
    public BlenderEmptyException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}